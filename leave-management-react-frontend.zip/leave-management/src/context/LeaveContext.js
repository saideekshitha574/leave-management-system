import { createContext, useState } from 'react';

export const LeaveContext = createContext();

export const LeaveProvider = ({ children }) => {
    const [leaves, setLeaves] = useState([]);
    const [balance, setBalance] = useState({ casual: 5, medical: 3 });

    const applyLeave = (type, days) => {
        if (balance[type] >= days) {
            setLeaves([...leaves, { type, days, status: 'Pending' }]);
            setBalance({ ...balance, [type]: balance[type] - days });
        } else {
            alert('Insufficient leave balance');
        }
    };

    return (
        <LeaveContext.Provider value={{ leaves, balance, applyLeave }}>
            {children}
        </LeaveContext.Provider>
    );
};

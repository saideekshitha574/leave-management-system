import { useLeave } from '../hooks/useLeave';

const LeaveDashboard = () => {
    const { balance, leaves } = useLeave();

    return (
        <div>
            <h2>Leave Dashboard</h2>
            <p>Casual Leave Balance: {balance.casual} days</p>
            <p>Medical Leave Balance: {balance.medical} days</p>

            <h3>Leave History</h3>
            <ul>
                {leaves.map((leave, index) => (
                    <li key={index}>
                        {leave.type} - {leave.days} days - {leave.status}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default LeaveDashboard;

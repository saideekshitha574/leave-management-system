import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { LeaveProvider } from './context/LeaveContext';
import ApplyLeave from './pages/ApplyLeave';
import LeaveDashboard from './pages/LeaveDashboard';

function App() {
    return (
        <LeaveProvider>
            <Router>
                <Routes>
                    <Route path="/apply" element={<ApplyLeave />} />
                    <Route path="/dashboard" element={<LeaveDashboard />} />
                </Routes>
            </Router>
        </LeaveProvider>
    );
}

export default App;

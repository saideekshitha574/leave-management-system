import { useContext } from 'react';
import { LeaveContext } from '../context/LeaveContext';

export const useLeave = () => {
    return useContext(LeaveContext);
};
